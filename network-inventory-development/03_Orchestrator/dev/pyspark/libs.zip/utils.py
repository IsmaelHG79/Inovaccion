# -*- coding: utf-8 -*-
#------------------------------------------------------------------------------------------------------------#
#	Nombre:		    utils.py                                            			                         #
#	Versi�n:	    1.1.0                                          			 		                         #
#	Objetivo: 	    Contiene funciones de usocomun para los programas de pyspark del HDFS                    #
#	Autor:		    ejesus				                                                                     #
#	V�a de ejecuci�n: L�nea de comandos		                                                            	 #
#	Fecha:		    4 de Agosto de 2020  	                                                           		 #
#	Area:		    Datalake AT&T											                                 #
#------------------------------------------------------------------------------------------------------------#


#-- **********************************************--#
#--                Area de imports                --#
#-- **********************************************--#
import os


#-- **********************************************--#
#--           Area de variables globales          --#
#-- **********************************************--#


#-- **********************************************--#
#--                 Area de funciones             --#
#-- **********************************************--#

#Funcion para leer la tabla donde se almacenan los ctl_eid a procesar
def read_properties(name_file):
	separator = "="
	props = {}

	with open(name_file) as f:
		for line in f:
			if separator in line:
				name, value = line.split(separator, 1)
				props[name.strip()] = value.strip()

	print(props)
	
	return props

#Funcion para generar la notificacion por correo electronico
def send_notification(mail_environment, mail_type, mail_schema, mail_table, mail_err, mail_type_flow):
	print "En funcion envia_mail"
	print("Envio de correo ambiente: {0}".format(mail_environment))
	print("Envio de correo tipo:     {0}".format(mail_type))
	print("Envio de correo esquema:  {0}".format(mail_schema))
	print("Envio de correo tabla:    {0}".format(mail_table))
	print("Envio de correo ruta log: {0}".format(mail_err))
	print("Envio de correo tipo comp:{0}".format(mail_type_flow))
	mail_params="{0} {1} {2} {3} {4}".format(mail_type,mail_schema,mail_table,mail_err,mail_type_flow)
	os.system("hdfs dfs -get /user/raw_rci/attdlkrci/{0}/shells/{0}_rci_asset_engine_send_mail.sh".format(mail_environment))
	os.system("chmod +x {0}_rci_asset_engine_send_mail.sh".format(mail_environment))
	os.system("./{1}_rci_asset_engine_send_mail.sh {0}".format(mail_params,mail_environment))
	print("Fin de envio de correo")

#Funcion para actualizar statu en tablas de Kudu
def update_status(update_environment, update_schema, update_table, update_state, update_user, update_table_id, update_ctl_eid, id_query):
	print "En funcion actualizar status"
	print("Actualizar con ambiente: {0}".format(update_environment))
	print("Actualizar con esquema:  {0}".format(update_schema))
	print("Actualizar con tabla:    {0}".format(update_table))
	print("Actualizar con status:   {0}".format(update_state))
	print("Actualizar con user:     {0}".format(update_user))
	print("Actualizar con table_id: {0}".format(update_table_id))
	print("Actualizar con ctl_eid:  {0}".format(update_ctl_eid))
	print("Actualizar con id_query: {0}".format(id_query))
	update_params="{0} {1} {2} {3} {4} {5} {6}".format(update_schema,update_table,update_state,update_user,update_table_id,update_ctl_eid,id_query)
	os.system("hdfs dfs -get /user/raw_rci/attdlkrci/{0}/shells/{0}_rci_template_update_kudu.sh".format(update_environment))
	os.system("chmod +x {0}_rci_template_update_kudu.sh".format(update_environment))
	os.system("./{1}_rci_template_update_kudu.sh {0}".format(update_params,update_environment))
	print("Fin de actualizar status")
